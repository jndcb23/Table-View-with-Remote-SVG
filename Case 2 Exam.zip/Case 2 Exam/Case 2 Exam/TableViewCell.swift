//
//  TableViewCell.swift
//  Case 2 Exam
//
//  Created by John Nikko Borja on 07/11/2019.
//  Copyright © 2019 John Nikko Borja. All rights reserved.
//

import UIKit
import SVGKit

class TableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var ciocLbl: UILabel!
//    @IBOutlet weak var alphaCodeLbl: UILabel!
//    @IBOutlet weak var populationLbl: UILabel!
    
    @IBOutlet weak var imgView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
