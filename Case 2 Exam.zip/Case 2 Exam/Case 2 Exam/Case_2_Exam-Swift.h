//
//  Case_2_Exam-Swift.h
//  Case 2 Exam
//
//  Created by John Nikko Borja on 07/11/2019.
//  Copyright © 2019 John Nikko Borja. All rights reserved.
//

#ifndef Case_2_Exam_Swift_h
#define Case_2_Exam_Swift_h


#endif /* Case_2_Exam_Swift_h */


#import <SVGKit/SVGKit.h>
#import <SVGKit/SVGKImage.h>
