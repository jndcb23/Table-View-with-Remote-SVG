//
//  ModelRepository.swift
//  Case 2 Exam
//
//  Created by John Nikko Borja on 07/11/2019.
//  Copyright © 2019 John Nikko Borja. All rights reserved.
//

import UIKit

class  ModelRepository: NSObject {
    var countryLbl:String = ""
    var imageName:String = ""
    var cioc:String = ""
    
    // details screen
    var capital:String = ""
    var alphaCode:String = ""
    var population:NSInteger = 0

    
    init(countryLbl:String,imageName:String,cioc:String,capital:String,alphaCode:String,population:NSInteger) {
        self.countryLbl = countryLbl
        self.imageName = imageName
        self.cioc = cioc
        self.capital = capital
        self.alphaCode = alphaCode
        self.population = population
    }
    
    class func generateModelArray(jsonObj: NSObject) -> [ModelRepository]{
        var modelAry = [ModelRepository]()
        
        if let allNameArray = jsonObj.value(forKey: "name") as? NSArray {
            if let allCiocArray = jsonObj.value(forKey: "cioc") as? NSArray {
                if let allFlagArray = jsonObj.value(forKey: "flag") as? NSArray {
                    if let allCapitalArray = jsonObj.value(forKey: "capital") as? NSArray {
                        if let alphaCodeArray = jsonObj.value(forKey: "alpha2Code") as? NSArray {
                            if let populationArray = jsonObj.value(forKey: "population") as? NSArray {
                                
                                for i in 0..<allNameArray.count {
                                    modelAry.append(ModelRepository(countryLbl: allNameArray.object(at: i) as! String , imageName: allFlagArray.object(at: i) as? String ?? "", cioc: allCiocArray.object(at: i) as? String ?? "" , capital: allCapitalArray.object(at: i) as? String ?? "" , alphaCode: alphaCodeArray.object(at: i) as? String ?? "" , population: populationArray.object(at: i) as? NSInteger ?? 0))
                                }
                            }
                        }
                    }
                }
            }
        }
        return modelAry
    }
}
