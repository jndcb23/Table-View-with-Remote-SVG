//
//  MasterViewController.swift
//  Case 2 Exam
//
//  Created by John Nikko Borja on 07/11/2019.
//  Copyright © 2019 John Nikko Borja. All rights reserved.
//

import UIKit
import SVGKit
import SDWebImageSVGCoder

enum selectedScope:Int {
    case nameLabel = 0
    case ciocVal = 1
}

class MasterViewController: UITableViewController, UISearchBarDelegate, UIWebViewDelegate {

    var urlString = "https://restcountries.eu/rest/v2/all"

    var initialDataArray:[ModelRepository]? = nil
    var dataArray:[ModelRepository]? = nil
    
    var nameArray = [String]()
    var ciocArray = [String]()
    var imgFlagURLArray = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.downloadJsonWithURL()
        self.searchBarSetup()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1){
            self.tableView.reloadData()
        }
    }
    
    // MARK: - JSON DATA
    func downloadJsonWithURL() {
        let url = URL(string:urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
        URLSession.shared.dataTask(with: ((url as URL?)!), completionHandler: {(data, response, error) -> Void in
            
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSArray {
                
                self.dataArray = ModelRepository.generateModelArray(jsonObj: jsonObj ?? "" as NSObject)
                self.initialDataArray = self.dataArray
            }
            OperationQueue.main.addOperation({
                self.tableView.reloadData()
            })
        }).resume()
    }
 
    func searchBarSetup() {
        let searchBar = UISearchBar(frame: CGRect(x:0,y:0,width:(UIScreen.main.bounds.width),height:70))
        searchBar.showsScopeBar = true
        searchBar.scopeButtonTitles = ["Name","Cioc"]
        searchBar.selectedScopeButtonIndex = 0
        searchBar.delegate = self
        self.tableView.tableHeaderView = searchBar
    }
    
    // MARK: - search bar delegate
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            self.tableView.reloadData()
        }
        else {
            filterTableView(ind: searchBar.selectedScopeButtonIndex, text: searchText)
        }
    }
    
    func filterTableView(ind:Int,text:String) {
        switch ind {

        case selectedScope.nameLabel.rawValue:

            self.dataArray = self.initialDataArray?.filter({ (mod) -> Bool in
                return mod.countryLbl.lowercased().contains(text.lowercased())
            })
            self.tableView.reloadData()

        case selectedScope.ciocVal.rawValue:

            self.dataArray = self.initialDataArray?.filter({ (mod) -> Bool in
                return mod.cioc.lowercased().contains(text.lowercased())
            })
            self.tableView.reloadData()
            
        default:
            print("no type")
        }
    }

    // MARK: - Table View
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataArray?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! TableViewCell
        
        let modelData = dataArray?[indexPath.row]
        
        cell.nameLbl.text = modelData?.countryLbl
        cell.ciocLbl.text = modelData?.cioc
        
        //Creating a page which will load our URL (Which points to our path)

        let svgURL = URL(string: modelData?.imageName ?? "")
//        let data = try? Data(contentsOf: svgURL ?? URL(string: "")!)
//        let img: SVGKImage = SVGKImage(data: data)
//        let namSvgImgVyuVar = SVGKImageView(svgkImage: img)
////        cell.imgView = SVGKFastImageView.init(svgkImage: img)
//        cell.imgView?.addSubview(SVGKLayeredImageView.init(svgkImage: namSvgImgVyuVar))
//        cell.imageView?.addSubview(SVGKFastImageView.init(svgkImage: img))

        let SVGCoder = SDImageSVGCoder.shared
        SDImageCodersManager.shared.addCoder(SVGCoder)
        cell.imageView?.sd_setImage(with: svgURL)
        let SVGImageSize = CGSize(width: 50, height: 50)
        cell.imageView?.sd_setImage(with: svgURL, placeholderImage: nil, options: [], context: [.svgImageSize : SVGImageSize])
        
        return cell
    }
    
    //add delegate method for pushing to new detail controller
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        vc.dataModel = dataArray?[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true;
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = false;
    }
    
    // dismiss keyboard
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
    }
    
    //Calls this function when the tap is recognized.
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    
}

