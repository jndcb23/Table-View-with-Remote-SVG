//
//  DetailViewController.swift
//  Case 2 Exam
//
//  Created by John Nikko Borja on 07/11/2019.
//  Copyright © 2019 John Nikko Borja. All rights reserved.
//

import UIKit
import SDWebImageSVGCoder


class DetailViewController: UIViewController {

    //from previous controller
    var dataModel:ModelRepository!
    
    //IBOutlets
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var countryNameLabel: UILabel!
    @IBOutlet weak var ciocLabel: UILabel!
    @IBOutlet weak var alphaCodeLabel: UILabel!
    @IBOutlet weak var population: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countryNameLabel.text = dataModel.countryLbl
        ciocLabel.text = dataModel.capital
        alphaCodeLabel.text = dataModel.alphaCode
        population.text = dataModel.population.description
//        imageView.image = UIImage(named: dataModel.imageName)
        
//        let svgURL = URL(string: dataModel.imageName )
//        let data = try? Data(contentsOf: svgURL ?? URL(string: "")!)
//        imageView.image = UIImage(data: data!)
        
        self.testMethod()
    }
    
    func testMethod() {
        let _: NSURL = NSURL(fileURLWithPath: dataModel?.imageName ?? "")
        
        let SVGCoder = SDImageSVGCoder.shared
        SDImageCodersManager.shared.addCoder(SVGCoder)
        
//        imageView?.sd_setImage(with: url)
        imageView.sd_setImage(with: URL(string: dataModel.imageName), placeholderImage:
            nil, options: SDWebImageOptions(),
                                               completed: { (image: UIImage?, error: Error?, cachetype: SDImageCacheType,
                                                imageURL: URL?) in
        })
        _ = CGSize(width: 100, height: 100)
//        self.imageView?.sd_setImage(with: url, placeholderImage: nil, options: [], context: [.svgImageSize : SVGImageSize])
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

