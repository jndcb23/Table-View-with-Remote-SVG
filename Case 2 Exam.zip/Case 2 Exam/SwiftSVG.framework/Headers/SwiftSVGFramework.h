//
//  SwiftSVGiOSFramework.h
//  SwiftSVGiOSFramework
//
//  Created by Matthias Schlemm on 25/06/15.
//  Copyright (c) 2015 Strauss LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftSVGiOSFramework.
FOUNDATION_EXPORT double SwiftSVGiOSFrameworkVersionNumber;

//! Project version string for SwiftSVGiOSFramework.
FOUNDATION_EXPORT const unsigned char SwiftSVGiOSFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftSVGiOSFramework/PublicHeader.h>


